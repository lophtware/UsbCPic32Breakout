/*
 * FreeRTOS Kernel V10.2.1
 * Copyright (C) 2019 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://www.FreeRTOS.org
 * http://aws.amazon.com/freertos
 *
 * 1 tab == 4 spaces!
 */

/*
 * Each profile corresponds to a different service. The demos that use the same
 * profile share the same service. It is important to understand the
 * correspondence between the preconfigured profiles and demos, since each
 * service have different connection configuration and credential validation.
 *
 *  - mqtt_demo_profile.h is preconfigured to test.mosquitto.org MQTT broker.
 * The file is used with mqtt_plain_text demo and mqtt_basic_tls_server_auth
 * demo. Feel free to try out other broker with the demos.
 *
 *  - https_demo_profile.h (current) is preconfigured to httpbin.org server.
 * The file is used with http_plain_text demo and https_basic_tls_server_auth
 * demo.
 *
 *  - aws_iot_demo_profile.h contains information to connect to AWS
 * IoT. The file is used with mqtt_tls_mutual_auth demo, https_tls_mutual_auth
 * demo, and other AWS IoT related demo.
 */

#ifndef HTTPS_DEMO_PROFILE_H
#define HTTPS_DEMO_PROFILE_H

#include "demo_config.h"

/**
 * @brief Details of the HTTPS server to connect to.
 *
 * Please note that many web servers will close the connection immediately after
 * sending the response in order to save resources. This demo is compatible only
 * with a server that persists the connection after sending a response.
 *
 * Port 443 is the standard port designated for encrypted HTTPS traffic.
 */
#define httpsdemoprofileSERVER_ADDRESS    "httpbin.org"


#if ( democonfigENABLE_TLS )
    #define httpsdemoprofileSERVER_PORT    443
#else
    #define httpsdemoprofileSERVER_PORT    80
#endif

/**
 * @brief The server certificate for httpbin.org:443.
 *
 * This certificate is obtained from https://httpbin.org/ and is used to
 * authenticate the HTTPS server. This demo only authenticates the server and
 * does not authenticate the client.
 *
 * If you want to connect to any other HTTPS server other than httpbin.org,
 * replace it with the certificate of the HTTPS server.
 */
#define httpsdemoprofileSERVER_CERTIFICATE_PEM                           \
    "-----BEGIN CERTIFICATE-----\n"                                      \
    "MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n" \
    "ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n" \
    "b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n" \
    "MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n" \
    "b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n" \
    "ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n" \
    "9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n" \
    "IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n" \
    "VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n" \
    "93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n" \
    "jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n" \
    "AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n" \
    "A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n" \
    "U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n" \
    "N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n" \
    "o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n" \
    "5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n" \
    "rqXRfboQnoZsG4q5WTP468SQvvG5\n"                                     \
    "-----END CERTIFICATE-----\n"


#endif /* ifndef HTTPS_DEMO_PROFILE_H */
