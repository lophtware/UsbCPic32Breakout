See https://freertos.org/jobs/ for further information.

Contains projects that demonstrate the Jobs library.

An AWS (Amazon Web Services) IoT Job is used to define a set of remote operations
that are sent to and executed on one or more devices connected to AWS IoT. Please
refer to AWS documentation for more information about AWS IoT Jobs.
https://docs.aws.amazon.com/iot/latest/developerguide/iot-jobs.html
