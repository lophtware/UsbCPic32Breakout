See https://freertos.org/shadow/ for further information.

Contains projects that demonstrate the Shadow library.

A device's Shadow is a JSON document that is used to store and retrieve current
state information for a device in AWS (Amazon Web Services) Cloud. Please refer to
the AWS documentation for more details about Device Shadow service.
https://docs.aws.amazon.com/iot/latest/developerguide/iot-device-shadows.html
