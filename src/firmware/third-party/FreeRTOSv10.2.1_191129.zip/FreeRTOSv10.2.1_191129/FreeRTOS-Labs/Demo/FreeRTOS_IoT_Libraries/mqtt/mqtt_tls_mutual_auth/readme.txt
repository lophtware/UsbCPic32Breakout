The MQTT mutual auth project will be added shortly.  In the mean time
https://github.com/aws/amazon-freertos provides demos with complete IoT
integrations that include mutually authenticated MQTT connections.