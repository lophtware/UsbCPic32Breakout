Contains examples of utility functions that are used by other FreeRTOS IoT
libraries.
